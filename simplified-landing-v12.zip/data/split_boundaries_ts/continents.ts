export const continentsPaths = []
