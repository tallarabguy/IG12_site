import IG12SimplifiedLanding from "../simplified-landing"

export default function Page() {
  return <IG12SimplifiedLanding />
}
